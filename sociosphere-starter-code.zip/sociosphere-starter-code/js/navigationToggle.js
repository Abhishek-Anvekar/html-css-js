function display()
{
  $(document).ready(function(){
    $('#icon').click(function(){
        $('ul').toggleClass('show');
    });
  });
}